const express = require('express');

    path = require('path');
    
    bodyParser = require('body-parser');
    cors = require('cors');
    mongoose = require('mongoose');
    config = require('./DB');
    

const businessRoute = require('./routes/lead.route');
mongoose.Promise = global.Promise;
mongoose.connect(config.DB, { useNewUrlParser: true }).then(
  () => {console.log('Database is connected') },
  err => { console.log('Can not connect to the database'+ err)}
);

const app = express();

app.use(express.static('E:/CRM_V2.1.4/backEnd/uploads'));
app.use(bodyParser.json());

app.use(bodyParser.urlencoded({extended: true}));
app.use(cors());
app.use(function (req, res, next) {
  res.setHeader('Access-Control-Allow-Origin', 'http://localhost:4200');
  res.setHeader('Access-Control-Allow-Methods', 'POST');
  res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');
  res.setHeader('Access-Control-Allow-Credentials', true);
  next();
});

app.use('/business', businessRoute);
const port = process.env.PORT || 4000;

const server = app.listen(port, function(){
  console.log('Listening on port ' + port);
});