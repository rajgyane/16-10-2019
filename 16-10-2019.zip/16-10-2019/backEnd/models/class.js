const mongoose = require('mongoose');
const Schema = mongoose.Schema;
// Define collection and schema for Users
let Class = new Schema({
    class_id:{type:String},
    class_name:{type: String},
},{
    collection: 'class'
});
module.exports = mongoose.model('Class', Class);