const mongoose = require('mongoose');
const Schema = mongoose.Schema;
// Define collection and schema for Users
let Lead_source = new Schema({
    lead_source_id:{type:String},
    lead_source_name:{type: String},
},{
    collection: 'lead_source'
});
module.exports = mongoose.model('Lead_source', Lead_source);