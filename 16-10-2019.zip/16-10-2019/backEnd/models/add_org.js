const mongoose = require('mongoose');
const Schema = mongoose.Schema;
// Define collection and schema for Users
let Add_org = new Schema({
full_name_org:{type: String},   
org_aliase:{type: String},
logo:{type: String},
address:{type:String},
status:{type:String},

},{
    collection: 'add_org'
});
module.exports = mongoose.model('Add_org', Add_org);