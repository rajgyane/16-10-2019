const mongoose = require('mongoose');
const Schema = mongoose.Schema;
let Followup_status = new Schema({
    status_id:{type: String},   
    status_name:{type: String}
},{
    collection: 'followup_status'
});

module.exports = mongoose.model('Followup_status', Followup_status);