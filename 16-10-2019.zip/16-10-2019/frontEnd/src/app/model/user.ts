export class User {
    email:string;   
    password:string;
    usertype:string;
    status:Number;
    assign_role:string;
    org_id:object;
    user_full_name:string;
}
