import { Injectable } from '@angular/core';
import{ HttpClient} from '@angular/common/http';
import{Router} from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class ServicesService {

  uri = 'http://localhost:4000/business';
  redirectUrl: string;

  constructor( private http:HttpClient,private route:Router) { }
  createLead(student_name,mobile_no,email_address,class_apply,country,state
    ,city,occupation,annual_income,query,district,pincode,leadsource,orgname) {
    const obj = {
      student_name: student_name,
      mobile_no: mobile_no,
      email_address: email_address,
      class_apply:class_apply,
      country:country,
      state:state,
      city:city,
      occupation:occupation,
      annual_income:annual_income,
      query:query,
      district:district,
      pincode:pincode,
      leadsource:leadsource,
      orgname:orgname
    };
    //console.log(obj);
    
    return this.http.post(`${this.uri}/add`, obj);
       
  }
  //check email status..

  check_alloted_mail(email)
  {
    const obj={ email:email};
    return this.http.post(`${this.uri}/check_alloted_email`, obj);

  }
  getLead() {
    return this
           .http
           .get(`${this.uri}`);
  }
  get_module_list()
  {
    return this
    .http
    .get(`${this.uri}/get_module_list`);
  }
  getCountry()
  {
    return this
           .http
           .get(`${this.uri}/country`);
  }
  getAuthorizationToken() {
    const currentUser = localStorage.getItem('token');
    return currentUser;
  }
  add_leadsourcedata(leadsource)
  {
    const obj={leadsource:leadsource};
    return this.http.post(`${this.uri}/add_leadsourcedata`, obj);
  }
  add_followupsstatus(followups)
  {
    const obj={followups:followups};
    return this.http.post(`${this.uri}/addFollowupstatus`, obj);
  }
  edit_lead_source_data_update(source_name,action_id)
  {
    const obj={source_name:source_name,action_id:action_id};
    return this.http.post(`${this.uri}/edit_lead_source_data_update`, obj);
  }
  deleteleadsourcedata(action_id)
  {
    const obj={action_id:action_id};
    return this.http.post(`${this.uri}/deleteleadsourcedata`, obj);
  }
  deletefollowupsstatusdata(action_id)
  {
    const obj={action_id:action_id};
    return this.http.post(`${this.uri}/deletefollowupsstatusdata`, obj);

  }

  edit_followups_update(change_value,action_id)
  {
    const obj={change_value:change_value,action_id:action_id};
    return this.http.post(`${this.uri}/edit_followups_update`, obj);
  }
  edit_followupstatus_data(id)
  {
    const obj={action_id:id};
    return this.http.post(`${this.uri}/edit_followupstatus_data`, obj);
  }
  getDetails(id)
  {
    const obj={id:id};
    return this.http.post(`${this.uri}/getDetails`, obj);
  }
  edit_lead_source_data(id)
  {
    const obj={id:id};
    return this.http.post(`${this.uri}/edit_lead_source_data`, obj);
  }
  getCity(district)
  {
     return this
            .http
            .get(`${this.uri}/Citylist/${district}`);
  

  }
  
  list_org()
  {
    return this
           .http
           .get(`${this.uri}/list_organization`);
  }
  user_list()
  {
    return this
           .http
           .get(`${this.uri}/user_list_data`);
  }
  assign_role_type()
  {
    return this
           .http
           .get(`${this.uri}/assign_role_type`);
  }
  getClass()
  {
    return this
           .http
           .get(`${this.uri}/getclasslist`);
  }
  getLeadsourcedata()
  {
    return this
           .http
           .get(`${this.uri}/getleadsourcelist`);
  }
  getFolowupstatuslist()
  {
    return this
           .http
           .get(`${this.uri}/getFolowupstatuslist`);
  }
  editLead(id) {
    return this
            .http
            .get(`${this.uri}/edit/${id}`);
    }
    getPincode(city)
    {
      return this
            .http
            .get(`${this.uri}/getPincode/${city}`);
    }
    permission_list()
    {
      return this
            .http
            .get(`${this.uri}/permission_list`);
    }
    updateAssignRole(row_id,role_type_id,role_name)
    {
      const obj={role_type_id:role_type_id,role_name:role_name};
      return this.http.post(`${this.uri}/updateAssignRole/${row_id}`, obj);

    }
    assign_permission(modules,role,org,status)
    {
      const obj={modules:modules,role:role,org:org,status:status};
      return this.http.post(`${this.uri}/assign_permission`, obj);

    }
    create_new_user(useremail,role_id,role_name,password,organization,userfullname)
    {
      const obj={useremail:useremail,role_id:role_id,role_name:role_name,password:password,
        organization:organization,
        userfullname:userfullname };
        return this.http.post(`${this.uri}/create_new_user`, obj);
        
    }
    editOrg(id)
    {
      return this
            .http
            .get(`${this.uri}/editorg/${id}`);
    }
    getState(country_code)
    {
      return this
            .http
            .get(`${this.uri}/state_list/${country_code}`);
    }
    getDistrict(state_code)
    {
      return this
      .http
      .get(`${this.uri}/district_list/${state_code}`);
    }
    lastFollowups(id)
    {
      return this
      .http
      .get(`${this.uri}/lastFollowup/${id}`);
    }
    module_list()
    {
      return this
      .http
      .get(`${this.uri}/module_list`);
    }
    listfollowups(id)
    {
      return this
      .http
      .get(`${this.uri}/listFollowups/${id}`);
    }
    add_organization(org_name,org_alise,upload_image,org_address)
    {
      const obj = { org_name: org_name,org_alise:org_alise,upload_image:upload_image,org_address:org_address}
      return this.http.post(`${this.uri}/addorganization`, obj);
      
     }
     updateOrgdata(org_name,org_alise,upload_image,org_address,org_status,id)
     {
      const obj = {
        full_name_org: org_name,
        org_aliase:org_alise,
        logo:upload_image,
        address:org_address,
        org_status:org_status
      }; 
      this
        .http
        .post(`${this.uri}/updateOrgdata/${id}`, obj)
        .subscribe(res => console.log(res)+'Update Data Successfully');

     }
    updateStudentData(student_name,
      class_apply,
      email_address,
      mobile_no,
      address1,
      address2,
      city,
      state,
      pin,
      information_source,
      father_name,
      mother_name,
      occupation,
      mother_occupation,
      father_org,
      mother_org,
      father_designation,
      mother_designation,
      alter_mobile_no,
      alter_email,
      current_school,
      percentage,
      dob,
      gender,
      sports,
      activity,
      no_of_brother,
      no_of_sister,
      brother_school_name1,
      sister_school_name1,
      brother_school_name2,
      sister_school_name2,
      reason_for_change,id)
      {
        const obj = {
          student_name: student_name,
          class_apply: class_apply,
          email_address: email_address,
          mobile_no:mobile_no,
          address1:address1,
          address2:address2,
          city:city,
          state:state,pin:pin,information_source:information_source,father_name:father_name,mother_name:mother_name,
          occupation:occupation,mother_occupation:mother_occupation,father_org:father_org,mother_org:mother_org,
          father_designation:father_designation,mother_designation:mother_designation,
          alter_mobile_no:alter_mobile_no,alter_email:alter_email,current_school:current_school,
          percentage:percentage,dob:dob,gender:gender,sports:sports,activity:activity,
          no_of_brother:no_of_brother,no_of_sister:no_of_sister,brother_school_name1:brother_school_name1,
          sister_school_name1:sister_school_name1,brother_school_name2:brother_school_name2,
          sister_school_name2:sister_school_name2,reason_for_change:reason_for_change
          };
          this
        .http
        .post(`${this.uri}/updateProfile/${id}`, obj)
        .subscribe(res => console.log(res)+'Update Data Successfully');

      }
      logout()
      {
        
        localStorage.removeItem('token');
        localStorage.removeItem('user_type');
        localStorage.removeItem('assign_role');
        localStorage.removeItem('org_id');
        localStorage.removeItem('permission_data');
       
        
        
        
        this.route.navigate(["/login"]);
       
      }
      login(email,password)
      {
        const obj={
          email:email,
          password:password
        };
        return this.http.post(`${this.uri}/login`,obj);
      }
      loggedIn()
      {
        //console.log('1');
        if (localStorage.getItem('token')) {
          return true;
        }
        return false;
        

      }
      submit_followups(status,followup,datetime,nextstep,expectedwalikin,ref)
      {
        const obj = {
          ref:ref,
          status: status,
          followup: followup,
          datetime: datetime,
          nextstep:nextstep,
          expectedwalikin:expectedwalikin};
          
           this
        .http
        .post(`${this.uri}/add_followups/${ref}`, obj).subscribe(res => console.log(res));

      }
    updateLead(student_name,mobile_no,email_address,class_apply,country,state
      ,city,occupation,annual_income,query,district,pincode,leadsource,orgname,id) {
        

      const obj = {
        student_name: student_name,
        mobile_no: mobile_no,
        email_address: email_address,
        class_apply:class_apply,
        state:state,
        city:city,
        occupation:occupation,
        annual_income:annual_income,
        query:query,
        district:district,
        pincode:pincode,
        country:country,
        leadsource:leadsource,
        orgname:orgname
      
      };
      this
        .http
        .post(`${this.uri}/update/${id}`, obj)
        .subscribe(res => console.log('Update Data Successfully'));
    }
    deleteLead(id) {
      return this
                .http
                .get(`${this.uri}/delete/${id}`);
    }
    deleteOrg(id)
    {
      //console.log(id);
        return this
                .http
                .get(`${this.uri}/deleteorg/${id}`);
    }
}
