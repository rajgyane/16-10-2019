import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import{ ReactiveFormsModule,FormsModule} from '@angular/forms';

import { AdminRoutingModule } from './admin-routing.module';
import { AdminComponent } from './admin/admin.component';
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';
import { MaterialModule} from '../material/material.module';
import { GoogleChartsModule } from 'angular-google-charts';
import { ChartsModule } from 'ng2-charts';

import { AdminFooterComponent } from './admin-footer/admin-footer.component';
import { LeadAddComponent } from './lead-add/lead-add.component';
import { LeadGetComponent } from './lead-get/lead-get.component';
import { ViewdetailsComponent } from './viewdetails/viewdetails.component';
import { DialogboxComponent } from './dialogbox/dialogbox.component';
import{ MessageboxComponent} from './messagebox/messagebox.component';
import { LeadEditComponent } from './lead-edit/lead-edit.component';
import { ViewfollowupsComponent } from './viewfollowups/viewfollowups.component';
import { FollowupsComponent } from './followups/followups.component';
import { AddOrganizationComponent } from './add-organization/add-organization.component';
import { FileSelectDirective } from 'ng2-file-upload';
import { ListOrgComponent } from './list-org/list-org.component';
import { EditOrgComponent } from './edit-org/edit-org.component';
import { UserListComponent } from './user-list/user-list.component';
import { AddUserComponent } from './add-user/add-user.component';
import { PermissionComponent } from './permission/permission.component';
import { LeadsourcelistComponent} from './lead-source-list/lead-source-list.component';
import { FollowupStatusListComponent } from './followup-status-list/followup-status-list.component';
import { AddleadsourceComponent } from './addleadsource/addleadsource.component';
import { EditleadsourcelistComponent } from './editleadsourcelist/editleadsourcelist.component';
import { DeletestatusdataComponent } from './deletestatusdata/deletestatusdata.component';
import { AddfollowupstatusComponent } from './addfollowupstatus/addfollowupstatus.component';
import { EditfollowupstatuslistComponent } from './editfollowupstatuslist/editfollowupstatuslist.component';


@NgModule({
  declarations: [AdminComponent, AdminDashboardComponent, AdminFooterComponent, LeadAddComponent, LeadGetComponent, ViewdetailsComponent, DialogboxComponent,MessageboxComponent, LeadEditComponent, ViewfollowupsComponent, FollowupsComponent, AddOrganizationComponent,FileSelectDirective, ListOrgComponent, EditOrgComponent, UserListComponent, AddUserComponent, PermissionComponent, LeadsourcelistComponent, FollowupStatusListComponent, AddleadsourceComponent, EditleadsourcelistComponent, DeletestatusdataComponent, AddfollowupstatusComponent, EditfollowupstatuslistComponent],
  imports: [
    CommonModule,MaterialModule,ReactiveFormsModule,FormsModule,GoogleChartsModule,ChartsModule,
    AdminRoutingModule
  ],
  entryComponents: [ViewdetailsComponent,DialogboxComponent,MessageboxComponent,AddUserComponent,AddleadsourceComponent,EditleadsourcelistComponent,DeletestatusdataComponent,AddfollowupstatusComponent,EditfollowupstatuslistComponent]
})
export class AdminModule { }
