import { Component, OnInit } from '@angular/core';
import{ ActivatedRoute,Router} from '@angular/router';
import{FormGroup,  FormBuilder,  Validators} from '@angular/forms';
import {ServicesService} from '../../auth/services.service';
import {Country} from '../../model/country';
import { State} from '../../model/state';
import {District} from '../../model/district';
import { City} from '../../model/city';
import { Class} from '../../model/class';
import { LeadSource} from '../../model/lead-source';
import {List_org} from '../../model/list_org';
import { MessageboxComponent} from '../messagebox/messagebox.component';
import { MatDialog, MatDialogConfig } from '@angular/material'; 


@Component({
  selector: 'app-lead-edit',
  templateUrl: './lead-edit.component.html',
  styleUrls: ['./lead-edit.component.css']
})
export class LeadEditComponent implements OnInit {
  lead:any={};
  angForm: FormGroup;
  select_country:string;
  country12:Country[]=[];
  statedata:State[]=[];
  districtdata:District[]=[];
  citydata:City[]=[];
  classdata:Class[]=[];
  leadsourcedata:LeadSource[]=[];
  listorgdata:List_org[]=[];
  pincodedata:any;
  res_pincode:any;
  res_state:any;
  res_district:any;
  res_city:any;

  constructor(private route: ActivatedRoute,
    private router: Router,
    private ls: ServicesService,
    private fb: FormBuilder,public dialog: MatDialog) {
      this.createForm();
 }
 createForm() {
  this.angForm = this.fb.group({
    student_name: ['', Validators.required ],
    mobile_no: ['', Validators.required],
    email_address: ['',Validators.compose([
      Validators.required,
      Validators.pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$')
    ]) ],
    class_apply: ['', Validators.required ],
    country:['', Validators.required ],
    state:['', Validators.required ],
    
    city:['', Validators.required ],
    occupation:['', Validators.required ],
    annual_income:['', Validators.required ],
    
    query:['', Validators.required ],
    district:['', Validators.required ],
    pincode:['', Validators.required ],
    lead_source_name:['', Validators.required ],
    org_list:['', Validators.required ],

  });
}

ngOnInit() {

  this.route.params.subscribe(params => {
      this.ls.editLead(params['id']).subscribe(res => {
        this.lead = res;
        this.angForm.patchValue({
          student_name:this.lead.student_name,
          mobile_no:this.lead.mobile_no,
          email_address:this.lead.email_address,
          class_apply:this.lead.class_apply,
          country:this.lead.country,
          state:this.lead.state,
          city:this.lead.city,
          occupation:this.lead.occupation,
          annual_income:this.lead.annual_income,
          query:this.lead.query,
          district:this.lead.district,
          pincode:this.lead.pincode,
          lead_source_name:this.lead.lead_source,
          org_list:this.lead.org_id
          //select_state(this.lead.country)  
        });
        this.select_country=this.lead.country;
        //console.log(this.select_country);
        if(this.select_country=='IN')
        {
          this.select_state12('IN');
          this.select_district12(this.lead.state);
          this.select_city12(this.lead.district);
          this.select_pincode12(this.lead.city);
          //alert('sadad');
        }
       //console.log( this.select_country);
    });
  });
  this.ls
  .getCountry()
  .subscribe((data: Country[]) => {
    this.country12 = data;
    
    //console.log(this.country12);
});
this.ls
      .getClass()
      .subscribe((data: Class[]) => {
        this.classdata = data;
              });
              this.ls
      .getLeadsourcedata()
      .subscribe((data: LeadSource[]) => {
        this.leadsourcedata = data;
        //console.log(this.leadsourcedata);
              });
              this.ls
      .list_org()
      .subscribe((data: List_org[]) => {
        this.listorgdata = data;
        
              });
}
keyPress(event: any) {
  const pattern = /[0-9\+\-\ ]/;

  let inputChar = String.fromCharCode(event.charCode);
  if (event.keyCode != 8 && !pattern.test(inputChar)) {
    event.preventDefault();
  }
}
select_state(country)
  {
    
    if(country.target.value!='')
    {
      this.select_country=country.target.value;
       this.ls
      .getState(country.target.value)
      .subscribe((data:State[]) => {
        this.statedata = data;
        
        //console.log(this.statedata);
});
this.districtdata=[];
if(country.target.value!='IN')
{
  
  this.res_state='';
  this.res_district='';
  this.res_city='';
  this.res_pincode='';
  this.angForm.patchValue({state:'',district:'',city:'',pincode:''});
  

}
    }
    
  }

  select_state12(country)
  {
    
    if(country!='')
    {
      this.select_country=country;
       this.ls
      .getState(country)
      .subscribe((data:State[]) => {
        this.statedata = data;
        
        //console.log(this.statedata);
});
this.districtdata=[];
if(country!='IN')
{
  
  this.res_state='';
  this.res_district='';
  this.res_city='';
  this.res_pincode='';
  

}
    }
    
  }
  select_district(state)
  {
    if(state.target.value!='')
    {
      this.ls
      .getDistrict(state.target.value)
      .subscribe((data:District[]) => {
        this.districtdata = data;
        //console.log(this.districtdata);
    });
    }}

    select_district12(state)
    {
      if(state!='')
      {
        this.ls
        .getDistrict(state)
        .subscribe((data:District[]) => {
          this.districtdata = data;
          //console.log(this.districtdata);
      });
      }}
select_city(district)
{
  if(district.target.value!='')
  {
    this.ls
      .getCity(district.target.value)
      .subscribe((data:City[]) => {
        this.citydata = data;
        //console.log(this.citydata);
    });
  }
}
select_city12(district)
{
  if(district!='')
  {
    this.ls
      .getCity(district)
      .subscribe((data:City[]) => {
        this.citydata = data;
        //console.log(this.citydata);
    });
  }
}
select_pincode(city)
{
  if(city.target.value!='')
  {
    this.ls
      .getPincode(city.target.value)
      .subscribe((data:any) => {
        this.pincodedata = data;
        this.res_pincode=this.pincodedata[0].pincode;
        //console.log(this.pincodedata[0].pincode);
    });

  }
}
select_pincode12(city)
{
  if(city!='')
  {
    this.ls
      .getPincode(city)
      .subscribe((data:any) => {
        this.pincodedata = data;
        this.res_pincode=this.pincodedata[0].pincode;
        //console.log(this.pincodedata[0].pincode);
    });

  }
}

updateLead() {
  let student_name= this.angForm.value.student_name;
  let mobile_no=this.angForm.value.mobile_no;
  let email_address=this.angForm.value.email_address;
  let class_apply=this.angForm.value.class_apply;
  let country=this.angForm.value.country;
  let state= this.angForm.value.state;
  let city=this.angForm.value.city;
  let occupation=this.angForm.value.occupation;
  let annual_income= this.angForm.value.annual_income;
  let query=this.angForm.value.query;
  let district= this.angForm.value.district;
  let pincode=this.angForm.value.pincode;
  let leadsource=this.angForm.value.lead_source_name;
  let orgname=this.angForm.value.org_list;
  this.route.params.subscribe(params => {
     this.ls.updateLead(student_name,mobile_no,email_address,class_apply,country,state
      ,city,occupation,annual_income,query,district,pincode,leadsource,orgname,params['id']);
      const dialogConfig1 = new MatDialogConfig();
    dialogConfig1.disableClose = true;
    dialogConfig1.autoFocus = true;
    dialogConfig1.width='300px';
    dialogConfig1.height='250px';

dialogConfig1.data = {
          
            response_data:'Update Data Successfully'
      
          };
          
          //const dialogRef = this.dialog.open(DialogboxComponent, dialogConfig);
          const dialogRef = this.dialog.open(MessageboxComponent, dialogConfig1);
          dialogRef.afterClosed().subscribe(result => {
            if(result==true)
            {
              
              this.router.navigate(['admin/lead']);
              
            }
            });
      
     
});
//this.ls.getLead();



}

}
