import { Component, OnInit  } from '@angular/core';
import {ServicesService} from '../../auth/services.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
  rightSideNav = true ;
  user_type:string;
  assign_role:string;
  mat_menu_status=false;
  list_module:any=[];
  permission_data:any=[];
 
  constructor(private router: Router,private _ls:ServicesService)
   { }

  ngOnInit() {
    //assign_role
    this.user_type=localStorage.getItem('user_type');
    this.assign_role=localStorage.getItem('assign_role');
   console.log(this.assign_role,'assign_role');
    this.permission_data=localStorage.getItem('permission_data').split(",");
   //console.log(this.permission_data);
   
    this._ls
    .get_module_list()
    .subscribe((data: any) => {
     
      this.list_module = data;
     //console.log(this.list_module);
     
     
      
});
  }
  check_module(module_id)
  {
    for(let x of this.permission_data)
    {
      //console.log(x,'mid1');
      if(x==module_id)
      {
        return true;
      }
    }
   }
  show_hide()
  {
    if(this.mat_menu_status == false)
    {
      this.mat_menu_status  = true;
    }
    else{
      this.mat_menu_status  = false;
    } 
  }
  sideNavBtnToggle()
  {
    if(this.rightSideNav == false)
    {
      this.rightSideNav  = true;
    }
    else{
      this.rightSideNav  = false;
    } 
    
}
logout()
  {
    this._ls.logout();
  }

}
