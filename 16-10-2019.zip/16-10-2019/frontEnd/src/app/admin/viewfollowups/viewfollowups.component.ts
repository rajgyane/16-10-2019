import { Component, OnInit,ViewChild } from '@angular/core';
import{ ServicesService} from '../../auth/services.service';
import{ ActivatedRoute,Router} from '@angular/router';
import { MatTableDataSource, MatSort, MatPaginator } from '@angular/material';
import Followups  from '../../model/followups';
import { Followupstatus} from '../../model/followupstatus';

@Component({
  selector: 'app-viewfollowups',
  templateUrl: './viewfollowups.component.html',
  styleUrls: ['./viewfollowups.component.css']
})
export class ViewfollowupsComponent implements OnInit {
  lead:any={};
  followupdata:any=[];
  Followup:Followups[]= [];
  followupstatus:Followupstatus[]=[];
  dataSource: MatTableDataSource<Followups>;
  @ViewChild(MatSort,{static: true}) sort: MatSort;
  @ViewChild(MatPaginator,{static: true}) paginator: MatPaginator;  
  displayedColumns: string[] = ['srno','status', 'followup', 'datetime', 'nextstep','expectedwalikin'];

  constructor(private route: ActivatedRoute,
    private router: Router,
    private ls: ServicesService) { }

  ngOnInit() {
    this.route.params.subscribe(params => {
      this.ls.editLead(params['id']).subscribe(res => {
        this.lead = res;
    });
  });
  this.route.params.subscribe(params => {
    
  this.ls.lastFollowups(params['id']).subscribe((data: Followups[]) => {
    this.Followup = data;
    console.log(this.Followup);
    this.dataSource = new MatTableDataSource(this.Followup);
this.dataSource.paginator = this.paginator;
this.dataSource.sort = this.sort;
  
});
});
  }
  applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
    this.dataSource.filter = filterValue;
  }

}
