import {Component, OnInit,ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ServicesService } from '../../auth/services.service';
import Followups  from '../../model/followups';
import { Followupstatus} from '../../model/followupstatus';
import { MatTableDataSource, MatSort, MatPaginator } from '@angular/material';
import { NativeDateAdapter, DateAdapter, MAT_DATE_FORMATS } from "@angular/material";
import { AppDateAdapter, APP_DATE_FORMATS} from '../app-date-adapter';
import { MessageboxComponent} from '../messagebox/messagebox.component';
import { MatDialog, MatDialogConfig } from '@angular/material';






@Component({
  selector: 'app-followups',
  templateUrl: './followups.component.html',
  styleUrls: ['./followups.component.css'],
  providers: [
    {
        provide: DateAdapter, useClass: AppDateAdapter
    },
    {
        provide: MAT_DATE_FORMATS, useValue: APP_DATE_FORMATS
    }
    ]
  
})
export class FollowupsComponent implements OnInit {
  lead: any = {};
  status:string;
  angForm: FormGroup;
  last_followups:any={};
  Followup:Followups[]= [];
  followupstatus:Followupstatus[]=[];
  fstatus: String='';
  addfstatus:String='';
  ffollowup: String='';
  fdatetime: String='';
  fnextstep: String='';
  fexpectedwalikin: String='';
  addedfollowupstatus:string;
  dataSource: MatTableDataSource<Followups>;
@ViewChild(MatSort,{static: true}) sort: MatSort;
@ViewChild(MatPaginator,{static: true}) paginator: MatPaginator;  
displayedColumns: string[] = ['srno','status', 'followup', 'datetime', 'nextstep','expectedwalikin'];


  constructor(private route: ActivatedRoute,
    private router: Router,
    private ls: ServicesService,
    private fb: FormBuilder,public dialog: MatDialog) { this.createForm(); }
    

  ngOnInit() {

    
    this.route.params.subscribe(params => {
      this.ls.lastFollowups(params['id']).subscribe((data: Followups[]) => {
        this.Followup = data;
        console.log(this.Followup);
        this.dataSource = new MatTableDataSource(this.Followup);
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
      
    });
    });
   this.ls
      .getFolowupstatuslist()
      .subscribe((data: Followupstatus[]) => {
        this.followupstatus = data;
        //console.log(this.followupstatus);
       });
       this.route.params.subscribe(params => {
        this.ls.editLead(params['id']).subscribe((data: any) => {
          this.lead = data;
          //console.log(this.lead);
          
                 
      });
      });

    

  }
  applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
    this.dataSource.filter = filterValue;
  }
  
  
  createForm() {
    this.angForm = this.fb.group({
      fstatus: ['', Validators.required],
      fdate: ['', Validators.required],
      student_next_step: ['', Validators.required],
      expected_walkin: ['', Validators.required],
      Followups: ['', Validators.required]
      
       });
  }
  public hasError = (controlName: string, errorName: string) =>{
    return this.angForm.controls[controlName].hasError(errorName);
  }
  
  add_followups()
  {
    let status=this.angForm.value.fstatus;
    let folowupdate=this.angForm.value.fdate;
    let student_next_step=this.angForm.value.student_next_step;
    let expected_walkin=this.angForm.value.expected_walkin;
    let followups=this.angForm.value.Followups;
    this.route.params.subscribe(params => {
      this.ls.submit_followups(status,followups,folowupdate,student_next_step,expected_walkin,params['id']);
      });
      //this.addedfollowupstatus='Added Followup Successfully!!';

      const dialogConfig1 = new MatDialogConfig();
    dialogConfig1.disableClose = true;
    dialogConfig1.autoFocus = true;
   
dialogConfig1.data = {
          
            response_data:'Added Followup Successfully'
      
          };
          dialogConfig1.width='300px';
          dialogConfig1.height='250px';
          //const dialogRef = this.dialog.open(DialogboxComponent, dialogConfig);
          const dialogRef = this.dialog.open(MessageboxComponent, dialogConfig1);
      setTimeout(() => 
{
  
  this.addedfollowupstatus='';
  this.ngOnInit();
},
150);
     

  }
  
  updateStudentData(
    student_name,
    class_apply,
    email_address,
    mobile_no,
    address1,
    address2,
    city,
    state,
    pin,
    information_source,
    father_name,
    mother_name,
    occupation,
    mother_occupation,
    father_org,
    mother_org,
    father_designation,
    mother_designation,
    alter_mobile_no,
    alter_email,
    current_school,
    percentage,
    dob,
    gender,
    sports,
    activity,
    no_of_brother,
    no_of_sister,
    brother_school_name1,
    sister_school_name1,
    brother_school_name2,
    sister_school_name2,
    reason_for_change)
    {
      this.route.params.subscribe(params => {
        this.ls.updateStudentData(student_name,
          class_apply,
          email_address,
          mobile_no,
          address1,
          address2,
          city,
          state,
          pin,
          information_source,
          father_name,
          mother_name,
          occupation,
          mother_occupation,
          father_org,
          mother_org,
          father_designation,
          mother_designation,
          alter_mobile_no,
          alter_email,
          current_school,
          percentage,
          dob,
          gender,
          sports,
          activity,
          no_of_brother,
          no_of_sister,
          brother_school_name1,
          sister_school_name1,
          brother_school_name2,
          sister_school_name2,
          reason_for_change,params['id']);
        });
     
    }
   

}
